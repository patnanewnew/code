#include<stdio.h>
void main()
{
int x;
int y;
int z = 890;
scanf("%d%d",&x,&y);
printf("%d",x+y);
printf("%d",x-y);
printf("%d",x*y);
printf("%d",x/y);
}
