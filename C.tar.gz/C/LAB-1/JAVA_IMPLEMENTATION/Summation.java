import java.util.Scanner;
public class Summation
{
	public static void main(String args[])
	{
		int cdckdbc=456;
		float d=22.45;
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
			System.out.println(a+b);
			System.out.println(a*b);
			System.out.println(a%b);
			System.out.println(a-b);
	}
}
