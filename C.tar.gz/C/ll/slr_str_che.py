tabl = {}
'''no = input("I number")
for i in range(no):
	x = input("number of value in \n")
	print i
	temp = []
	for j in range(x):
		temp.append((raw_input("symbol\n"),raw_input("to\n")))
	tabl[i] =temp'''
gramar= {1:("S","AA"),2:("A","aA"),3:("A","b")}
#tabl = {0:[("a","s3"),("b","s4"),("A","s2"),("S","s1")],2:[("a","s3"),("b","s4"),("A","5")],3:[("a","s3"),("b","s4"),("A","6")],4:[("a","r3"),("b","r3"),("$","r3")],5:[("$","r1")],6:[("a","r2"),("b","r2"),("$""r2")],1:[("$","accept")]}
stack = "$0"
string = raw_input("enter string")+'$'
action = {}
i = 0
while True:
	print stack[-1]
	line = tabl[int(stack[-1])]
	for element in line:
		print string[0]
		if element[0]==string[0]:
			if element[1][0] == "s":
				action[i] =element
				stack = stack + string[0] + element[1][-1]	
				string = string[1:]
				print stack,"stack"
				print string,"string"
				break
			elif element[1] == "accept":
				break
			elif element[1][0] == "r":
				l = len(stack)-2*len(gramar[int(element[1][-1])][1])
				print "index",l
				stack = stack[0:l]
				action[i] =element
				stack = stack + gramar[int(element[1][-1])-1][0] + element[1][-1]	
				string = string[1:]
				print stack,"stack"
				print string,"string"
				break
			else:
				print "not accepted"
				
			
	i = i+1
	if len(string)==1:
		print "succesfull"
		break
print action 
