# CompilerDesign_A2-IIITS_2014
C program to construct an SLR(1) parse table that also checks if a given string is in the given grammar or not.



Code refernces :

  https://programsinengineering.blogspot.in/2016/03/slr-parser-c-program.html
  
  http://crazywebappdeveloper.blogspot.in/2013/10/follow-set-of-given-grammar-using-c.html
  
  http://www.coders-hub.com/2013/05/c-code-for-slr-parser.html#.Wdfk3bNaHeR
