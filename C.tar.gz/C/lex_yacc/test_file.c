#include<stdio.h>

int main()
{
int a,b,c;
printf("Enter two numbers to add\n");
scanf("%d %d ",&a,&b);

c=a+b;
printf("\nSum of enterd numbers are %d \n",c);
return 0;
}
