arr=[]
final=[]
temp=[]
flag=0
n=int(raw_input("Enter the no of productions you want"))
for i in range(0,n):
    arr.append(raw_input())
d=dict()
for i in range(0,len(arr)):
    d[arr[i][0]]=''
for key in d:
    t=[]
    for i in range(0,len(arr)):
        if(arr[i][0]==key):
            t.append(arr[i][3:len(arr[i])+1])
    d[key]=t    
for key in d:
    temp=d[key]
    flag=0
    for i in range(0,len(temp)):
        if(i==0):
            s=temp[i]
        else:
            m=max(len(s),len(temp))
            for j in range(m,0,-1):
                if(s[0:j]==temp[i][0:j]):
                    s=temp[i][0:j]
                    break
                else:
                    if(j==1):
                        flag=1
                    continue
    if(flag==1):
        for i in temp:
            final.append(key+"->"+`i)
    else:
        final.append(key+"->"+s+key+"'")
        for k in range(0,len(temp)):
            final.append(key+"'"+"->"+temp[k][len(s):len(temp[k])+1])
print final
