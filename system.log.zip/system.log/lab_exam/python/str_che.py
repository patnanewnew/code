grammer = {"E+F":["E"],"F":["E"],"F*G":["F"],"G":["F"],"id":["G"]}
#grammer = {"aAb":["E"],"e":["A"],"a":["A"],"b":["B"]}
def find_substr(s, char):
    index = 0

    if char in s:
        c = char[0]
        for ch in s:
            if ch == c:
                if s[index:index+len(char)] == char:
                    return index

            index += 1

    return -1
def change_left(substring,key1,gram):
	return substring.replace(key1,gram)
def xyz(string):
	for key in grammer:
		if key in string:
			pos = find_substr(string,key) 
			string = string[0:pos] + change_left(string[pos:pos+len(key)],key,grammer[key][0]) + string[pos+len(key):len(string)]
			print string
			if string=="E":
				print "Accepted" 
			xyz(string)
			break
string = "id+id*id"
xyz(string)
