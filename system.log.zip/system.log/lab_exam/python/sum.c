#include<stdio.h>
void main()
{
/*gaurav*/
int a,b;
printf("enter two number");
scanf("%d%d",&a,&b);
int s = a+b;
printf("sum is %d",s);
}

