import re
f = open('sum.c','r')
operators = [ '=','+', '-', '/', '*', '++', '--','=','<','>']
keyword = ["if","else","while","do","break","continue","int","double", "float","return","char","case","char","sizeof","long","short","typedef","switch","unsigned","void","static","struct","goto","include"]
delimiter = [';','{','}',',','#']
numerals = ['0','1','2','3','4','5','6','7','8','9','10']
function = ["printf", "scanf", "gets", "puts", "strcpy", "strlen", "strcmp", "isdigit", "strcat", "isupper", "strstr", "islower", "isalpha"]
library =  ["stdio", "conio", "string", "stdlib", "math", "time", "ctype", "isdigit", "stdarg", "setjmp", "signal","errno", "assert"]
i = f.read()
program =  i.split('\n')

for line in program:
    tokens = re.findall(r"[\w']+", line)
    for token in tokens:
        if token in operators:
            print "Operator is: ",token
        elif token in keyword:
            print "keyword is: ",token            
        elif token in delimiter:
            print "Delimiter:" ,token
        elif token in numerals:
            print "constant:", token
	elif token in function:
	    print "function:",token
	elif token in library:
	    print "library:",token	
	elif token!='h':
	    print "identifier:",token
f.close()
