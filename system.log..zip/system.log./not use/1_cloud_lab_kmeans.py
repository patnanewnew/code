import numpy as np
from sklearn.cluster import KMeans
from sklearn.datasets.samples_generator import make_blobs
import pylab as pl
#generate sample data
centers = [[1,1],[-1,1],[-1,-1],[1,-1]]
X,labels_true=make_blobs(n_samples=750, centers=centers,cluster_std=0.4)

kmeans=KMeans(init='k-means++',n_clusters=4,n_init=10)
kmeans.fit(X)

centroids=kmeans.cluster_centers_
labels=kmeans.labels_

#no. of clusters in labels,ignoring noise if present
n_clusters_=len(set(labels))-(1 if -1 in labels else 0)


#plotting
h=.02

#plot
x_min,x_max = X[:,0].min(),X[:,0].max()
y_min,y_max = X[:,1].min(),X[:,1].max()
xx,yy =np.meshgrid(np.arange(x_min,x_max,h),np.arange(y_min,y_max,h))
#Obtain labels for each point in mesh. Use last trained model.
Z = kmeans.predict(np.c_[xx.ravel(),yy.ravel()])
#Put the result into a color plot
Z =Z.reshape(xx.shape)
pl.figure(1)
pl.clf()
pl.imshow(Z,Interpolation='nearest',
          extent=(xx.min(),xx.max(),yy.min(),yy.max()),
          cmap=pl.cm.Paired,
          aspect='auto',origin='lower')

pl.plot(X[:,0],X[:,1],'k.', markersize=2)
# Plot the centroids as a white
centroids =kmeans.cluster_centers_
pl.scatter(centroids[:,0],centroids[:,1],
    marker='x',s=169,linewidths=3,
    color='w',zorder=10)
z=pl.xlim(x_min,x_max)
pl.ylim(y_min,y_max)
import pylab
pylab.show()
pylab.savefig("/home/ubuntu/image.png")



