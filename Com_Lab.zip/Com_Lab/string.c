#include<stdio.h>
#include<stdlib.h>
void main()
{
	
	char array[100];
	int init, fin, l, i=0, b=0;

	printf("Input:");
	
	printf("Enter the string: ");
	scanf("%s", array);
	printf("\n\n");
	printf("Output:");

	
	if(array[0] == 'b')
	{	      if(array[1] == 'a') //ba
			       {	init = 2; i=2;
					    while(array[i] != '\0')
{
									i++;
								}	
fin= i-1;
if(array[fin] = 'c'){
									for(i=init; i<fin; i++)
										{ if(array[i] != 'b') {printf("\nMatch not found\n"); exit(0);}
										}
									printf("\n String matched with the regular expression bab*c ");
  }
  else {printf("\nMatch not found.\n");}
        }	
 else if(array[1] == 'b')
{   init = 2; i=2;
while(array[i] != '\0')
									{
										i++;
}	
fin= i-1;
if(array[fin] = 'b'){
											for(i=init; i<fin; i++)
												{ if(array[i] != 'a') {printf("\nMatch not found\n"); exit(0);}
												}
									         printf("\n String matched with the regular expression bba*b ");
  } 
else {printf("\nMatch not found.\n");}
					    
					 
}
 else {
 printf("\n your string don't match.");
 } 
}

else if(array[0] == 'a') //a
 {if(array[1] == 'c')
{ i=2;
 while(array[i] != 'b')
{if(array[i] != 'c'){printf("\nMatch not found.\n"); exit(0); }
i++;
}
if(array[i] ='b'){ i++;}
 while(array[i] != '\0')
{ if(array[i] != 'b')
{printf("\nMatch not found.\n.");
 exit(0);
}				       
i++;
}
printf("\n String matched with the regular expression ac*b+ ");
  }
 else if(array[1] =='b')
{i=2; 
 while(array[i] != '\0')
										{if(array[i] != 'b')
											{printf("\nMatch not found.\n"); 
											 exit(0);
										    }
											i++;
										}
 printf("\n String matched with the regular expression ac*b+ ");	
}
else printf("\nMatch not found.\n");
}
	
        
	
		 
}
