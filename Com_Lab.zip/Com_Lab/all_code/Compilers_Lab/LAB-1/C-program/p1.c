#include<stdio.h>
void main()
{
int a,b ,c;
a=12;
b=23;
c=a+b;
printf("%d",c);

}
