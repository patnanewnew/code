gra=[]
gra.append('S->CC')
gra.append('C->aC')
gra.append('C->d')
table=[]
x=[]
x.append('S3')
x.append('S4')
x.append(0)
x.append(1)
x.append(2)
table.append(x)
x=[]
x.append(0)
x.append(0)
x.append('acc')
x.append(0)
x.append(0)
table.append(x)
x=[]
x.append('S3')
x.append('S4')
x.append(0)
x.append(0)
x.append(5)
table.append(x)
x=[]
x.append('S3')
x.append('S4')
x.append(0)
x.append(0)
x.append(6)
table.append(x)
x=[]
x.append('R3')
x.append('R3')
x.append('R3')
x.append(0)
x.append(0)
table.append(x)
x=[]
x.append(0)
x.append(0)
x.append('R1')
x.append(0)
x.append(0)
table.append(x)
x=[]
x.append('R2')
x.append('R2')
x.append('R2')
x.append(0)
x.append(0)
table.append(x)
print table
stack=[]
stack.append(0)
inp=raw_input('')
inp=inp+'$'
dic=dict()
dic['a']=0
dic['d']=1
dic['$']=2
dic['S']=3
dic['C']=4
while(1):
	i=stack[len(stack)-1]
	j=inp[0]
	k=dic[j]
	print i
	print k
	y=table[int(i)][int(k)]
	print table[1][2][0]
	print y
	if y=='acc':
		print "accept"
		break
	elif y==0:
		print "reject"
		break
	elif(y[0]=='S'):
		r=y[1]
		stack.append(j)
		stack.append(r)
		inp=inp[1:len(inp)]
		print stack
		print inp
	elif(y[0]=='R'):
		r=y[1]
		print r
		g=gra[int(r)-1]
		print stack
		stack=stack[0:len(stack)-(2*(len(g)-3))]
		print stack
		w=stack[len(stack)-1]
		s=g[0]
		d=dic[s]
		print len(g)
		p=table[int(w)][int(d)]
		stack.append(s)
		stack.append(p)

