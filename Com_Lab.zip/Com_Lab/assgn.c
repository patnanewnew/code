#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<string.h>
int main()
{
char c;
char c[10][20]={"include","main","printf","char","c","scanf","(","@","$","/"};
    FILE *fp;
int i;
    fp = fopen ("/home/sanjay/Desktop/Com_Lab/sum.c", "r");	
	 if (fp== NULL) {
			printf("\nError,File can't open\n");
       		        exit(1);
   			 }
	printf("1.PUNCTUATION MARKS:- \n");
    while(( c= fgetc(fp)) != EOF)
    {	
		if (ispunct(c))
                { 
                 printf("%d", c);		
		 printf("\t");
                }
    }
}


