#include<stdio.h>
void main()
{
float a,b,sum;
scanf("%f",&a);
scanf("%f",&b);
sum=a+b;
printf("Sum is %f\n\n",sum);
}
