#include<stdio.h>
int main()
{
char c={"include","main","printf","char","c","scanf","(","@","$","/","8"};
int result;
 result = ispunct(c);
    
    if (result != 0)
    {
        printf("%c is a punctuation\n", c);
    }
    else
    {
        printf("%c is not a punctuation\n", c);
    }

    return 0;
}


