#include <stdio.h>
#include <ctype.h>
int main()
{
    char c;
    int result;

    c = '1';
    result = ispunct(c);

    if (result != 0)
    {
        printf("%c is a punctuation\n", c);
    }
    else
    {
        printf("%c is not a punctuation\n", c);
    }

    return 0;
}
