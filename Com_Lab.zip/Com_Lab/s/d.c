#include <stdio.h>

main(){

char a = 'a';
char filename[64];

FILE *out;
sprintf(filename, "%c.txt", a)

out = fopen( filename, "w");

fclose(out);

return 0;
}
