#include <stdio.h>
#include <ctype.h>
int main()
{
    int A[20];
printf("enter the program :");
scanf("%d",A);
    int result;

 
    result = ispunct(A);

    if (result != 0)
    {
        printf("%Ais a punctuation", A);
    }
    else
    {
        printf("%A is not a punctuation\n", A);
    }

    return 0;
}
