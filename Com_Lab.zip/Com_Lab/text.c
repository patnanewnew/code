#include<stdio.h>
void main()
{
FILE *fp;
char s[100];
//file to open
fp=fopen("h.txt","w+");
fputs("this is tutrialpoint",fp);
fseek(fp,-10L,2);
fputs("c programming",fp);

fclose(fp);
}
